<script setup>
//import { ElInput,ElButton} from 'element-plus'; 
//import LoginView from '@/views/LoginView.vue';
//import Hello from '@/views/ReisterView.vue';
</script>

<template>
  <RouterView></RouterView>
</template>

<style>
html,
/* 对页面进行排版 */
body {
  height: 98.5%;
  overflow: hidden;
}

#app {
  height: 100%;
  overflow: hidden;
}
</style>
