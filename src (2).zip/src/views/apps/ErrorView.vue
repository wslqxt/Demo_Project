<script setup>

</script>

<template>
我是错误页面
</template>

<style scoped>

</style>