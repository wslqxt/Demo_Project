<script setup>

</script>

<template>
  <h1>软件实训</h1>
</template>

<style scoped>

</style>