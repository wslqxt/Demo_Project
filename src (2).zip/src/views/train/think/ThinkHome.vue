<script setup>

</script>

<template>
<div>我是计算思维模板</div>
</template>

<style scoped>

</style>