<script setup>

</script>

<template>
我是注册页面
</template>

<style scoped>

</style>