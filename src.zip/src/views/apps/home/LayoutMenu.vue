<script setup>
import { ro } from 'element-plus/es/locales.mjs';
import { useRouter } from 'vue-router';
const router =useRouter();
const fnc=()=>{
  router.push({path:'/train/think'});
}
</script>

<template>
      <el-menu
        active-text-color="#ffd04b"
        background-color="#545c64"
        text-color="#fff"
        :router="true"
      >
        <el-sub-menu index="1">
          <template #title>
            <el-icon><Odometer /></el-icon>
            <span>课程实训</span>
          </template>
          <el-menu-item-group title="Group One">
            <el-menu-item index="1-1" route="/train/think">计算思维</el-menu-item>
            <el-menu-item index="1-2" route="/train/hard">硬件实训</el-menu-item>
            <el-menu-item index="1-3" route="/train/soft">软件实训</el-menu-item>
          </el-menu-item-group>
        </el-sub-menu>
            <el-sub-menu index="2">
          <template #title>
            <el-icon><Coordinate /></el-icon>
            <span>专业实习</span>
          </template>
          <el-menu-item-group title="Group Two">
            <el-menu-item index="2-1" route="/pract/central">集中实习</el-menu-item>
            <el-menu-item index="2-2" route="/pract/enterprise">企业实习</el-menu-item>
          </el-menu-item-group>
        </el-sub-menu>
         <el-sub-menu index="3">
          <template #title>
            <el-icon><School /></el-icon>
            <span>毕业设计</span>
          </template>
          <el-menu-item-group title="Group Three">
            <el-menu-item index="3-1">选题申报 </el-menu-item>
            <el-menu-item index="3-2">开题答辩</el-menu-item>
            <el-menu-item index="3-3">过程指导</el-menu-item>
            <el-menu-item index="3-4">论文答辩 </el-menu-item>
            <el-menu-item index="3-5">论文提交</el-menu-item>
          </el-menu-item-group>
        </el-sub-menu>
         <el-sub-menu index="4">
          <template #title>
           <el-icon><Orange /></el-icon>
            <span>临时测试</span>
          </template>
          <el-menu-item-group title="Group Four">
          </el-menu-item-group>
        </el-sub-menu>
        
        
      </el-menu>

</template>

<!-- <script lang="ts" setup>
import {
  Document,
  Menu as IconMenu,
  Location,
  Setting,
} from '@element-plus/icons-vue'

const handleOpen = (key: string, keyPath: string[]) => {
  console.log(key, keyPath)
}
const handleClose = (key: string, keyPath: string[]) => {
  console.log(key, keyPath)
}
</script> -->

<style scoped>

</style>