<script setup>

</script>

<template>
<h1>硬件实训</h1>
</template>

<style scoped>

</style>