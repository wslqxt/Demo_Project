
import { createRouter,createWebHashHistory } from "vue-router";

import HomeFrame from "../views/apps/home/HomeFrame.vue";


const homeRoutes=[
    {
        path:'/train/think',
        component:()=>import('@/views/train/think/ThinkHome.vue'),
        name:'ThinkHome',
    },
      {
        path:'/train/hard',
        component:()=>import('@/views/train/hard/HardHome.vue'),
        name:'HardHome',
    },
      {
        path:'/train/soft',
        component:()=>import('@/views/train/soft/SoftHome.vue'),
        name:'SoftHome',
    },
    {
        path:'/pract/central',
        component:()=>import('@/views/pract/central/CentralHome.vue'),
        name:'CentralHome',
    },
    {
        path:'/pract/enterprise',
        component:()=>import('@/views/pract/enterprise/EnterpriseHome.vue'),
        name:'EnterpriseHome',
    },
];
const routes=[{
    path:'/',
    component:HomeFrame,
    name:'HomeFrame',
    children: homeRoutes,
},{
    path:'/login',
    component:()=>import('@/views/apps/LoginView.vue'),
    name:'LoginView',
},{
    path:'/register',
    component:()=>import('@/views/apps/RegisterView.vue'),
    name:'RegisterView',
},{
    path:'/error',
    component:()=>import('@/views/apps/ErrorView.vue'),
    name:'ErrorView',
}];
const history=createWebHashHistory(import.meta.env.BASE_URL)
const router=createRouter({
    routes,
    history,
});

export default router;

